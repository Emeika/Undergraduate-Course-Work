#include <stdio.h>
void main()
{
        int j = 2;
    int motor, sensorValue = 0;
    if(motor == 1)    {
        sensorValue++;
    }
    else if(motor == 0)    {
        sensorValue--;
    }
    return 0;
}
