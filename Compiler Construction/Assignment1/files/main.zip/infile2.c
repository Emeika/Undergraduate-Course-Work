/*Program Name: in1.c
*Description:
    Input file for assignment 1
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//defining macros
#define MESSAGE1    "Hello class\n"
#define Message2    "Computer Science Department"

void main()
{

    ///////////Print messages

    printf(MESSAGE1);
    printf(Message2);



    return 0;
}