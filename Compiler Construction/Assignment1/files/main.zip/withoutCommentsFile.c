#include <stdio.h>
#define ON 1
#define OFF 0
void main()
{
        int j = 2;
    int motor, sensorValue = 0;
    if(motor == ON)    {
        sensorValue++;
    }
    else if(motor == OFF)    {
        sensorValue--;
    }
    return 0;
}
